﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags5
    {
        public DateTime Utc { get; set; }
        public byte? FC97 { get; set; }
        public byte? FC98 { get; set; }
        public byte? FC99 { get; set; }
        public byte? FC100 { get; set; }
        public byte? FC101 { get; set; }
        public byte? FC102 { get; set; }
        public byte? FC103 { get; set; }
        public byte? FC104 { get; set; }
        public byte? FC105 { get; set; }
        public byte? FC106 { get; set; }
        public byte? FC107 { get; set; }
        public byte? FC108 { get; set; }
        public byte? FC109 { get; set; }
        public byte? FC110 { get; set; }
        public byte? FC111 { get; set; }
        public byte? FC112 { get; set; }
        public byte? FC113 { get; set; }
        public byte? FC114 { get; set; }
        public byte? FC115 { get; set; }
        public byte? FC116 { get; set; }
        public byte? FC117 { get; set; }
        public byte? FC118 { get; set; }
        public byte? FC119 { get; set; }
        public byte? FC120 { get; set; }
        public byte? GC97 { get; set; }
        public byte? GC98 { get; set; }
        public byte? GC99 { get; set; }
        public byte? GC100 { get; set; }
        public byte? GC101 { get; set; }
        public byte? GC102 { get; set; }
        public byte? GC103 { get; set; }
        public byte? GC104 { get; set; }
        public byte? GC105 { get; set; }
        public byte? GC106 { get; set; }
        public byte? GC107 { get; set; }
        public byte? GC108 { get; set; }
        public byte? GC109 { get; set; }
        public byte? GC110 { get; set; }
        public byte? GC111 { get; set; }
        public byte? GC112 { get; set; }
        public byte? GC113 { get; set; }
        public byte? GC114 { get; set; }
        public byte? GC115 { get; set; }
        public byte? GC116 { get; set; }
        public byte? GC117 { get; set; }
        public byte? GC118 { get; set; }
        public byte? GC119 { get; set; }
        public byte? GC120 { get; set; }
    }
}
