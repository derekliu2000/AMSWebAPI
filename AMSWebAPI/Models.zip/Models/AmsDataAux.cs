﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataAux
    {
        public DateTime Utc { get; set; }
        public short? A1 { get; set; }
        public short? A2 { get; set; }
        public short? A3 { get; set; }
        public short? A4 { get; set; }
        public short? A5 { get; set; }
        public short? A6 { get; set; }
        public short? A7 { get; set; }
        public short? A8 { get; set; }
        public short? A9 { get; set; }
        public short? A10 { get; set; }
        public short? A11 { get; set; }
        public short? A12 { get; set; }
        public short? A13 { get; set; }
        public short? A14 { get; set; }
        public short? A15 { get; set; }
        public short? A16 { get; set; }
        public short? A17 { get; set; }
        public short? A18 { get; set; }
        public short? A19 { get; set; }
        public short? A20 { get; set; }
        public short? A21 { get; set; }
        public short? A22 { get; set; }
        public short? A23 { get; set; }
        public short? A24 { get; set; }
        public short? A25 { get; set; }
        public short? A26 { get; set; }
        public short? A27 { get; set; }
        public short? A28 { get; set; }
        public short? A29 { get; set; }
        public short? A30 { get; set; }
        public short? A31 { get; set; }
        public short? A32 { get; set; }
    }
}
