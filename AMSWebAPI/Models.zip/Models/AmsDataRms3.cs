﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms3
    {
        public DateTime Utc { get; set; }
        public short? C49 { get; set; }
        public short? C50 { get; set; }
        public short? C51 { get; set; }
        public short? C52 { get; set; }
        public short? C53 { get; set; }
        public short? C54 { get; set; }
        public short? C55 { get; set; }
        public short? C56 { get; set; }
        public short? C57 { get; set; }
        public short? C58 { get; set; }
        public short? C59 { get; set; }
        public short? C60 { get; set; }
        public short? C61 { get; set; }
        public short? C62 { get; set; }
        public short? C63 { get; set; }
        public short? C64 { get; set; }
        public short? C65 { get; set; }
        public short? C66 { get; set; }
        public short? C67 { get; set; }
        public short? C68 { get; set; }
        public short? C69 { get; set; }
        public short? C70 { get; set; }
        public short? C71 { get; set; }
        public short? C72 { get; set; }

        public virtual AmsDataRmsflags3 AmsDataRmsflags3 { get; set; }
    }
}
