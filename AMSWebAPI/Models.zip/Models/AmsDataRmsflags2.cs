﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRmsflags2
    {
        public DateTime Utc { get; set; }
        public byte? C25 { get; set; }
        public byte? C26 { get; set; }
        public byte? C27 { get; set; }
        public byte? C28 { get; set; }
        public byte? C29 { get; set; }
        public byte? C30 { get; set; }
        public byte? C31 { get; set; }
        public byte? C32 { get; set; }
        public byte? C33 { get; set; }
        public byte? C34 { get; set; }
        public byte? C35 { get; set; }
        public byte? C36 { get; set; }
        public byte? C37 { get; set; }
        public byte? C38 { get; set; }
        public byte? C39 { get; set; }
        public byte? C40 { get; set; }
        public byte? C41 { get; set; }
        public byte? C42 { get; set; }
        public byte? C43 { get; set; }
        public byte? C44 { get; set; }
        public byte? C45 { get; set; }
        public byte? C46 { get; set; }
        public byte? C47 { get; set; }
        public byte? C48 { get; set; }

        public virtual AmsDataRms2 UtcNavigation { get; set; }
    }
}
