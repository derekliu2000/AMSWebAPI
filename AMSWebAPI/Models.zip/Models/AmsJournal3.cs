﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsJournal3
    {
        public DateTime Utc { get; set; }
        public byte? C49 { get; set; }
        public byte? C50 { get; set; }
        public byte? C51 { get; set; }
        public byte? C52 { get; set; }
        public byte? C53 { get; set; }
        public byte? C54 { get; set; }
        public byte? C55 { get; set; }
        public byte? C56 { get; set; }
        public byte? C57 { get; set; }
        public byte? C58 { get; set; }
        public byte? C59 { get; set; }
        public byte? C60 { get; set; }
        public byte? C61 { get; set; }
        public byte? C62 { get; set; }
        public byte? C63 { get; set; }
        public byte? C64 { get; set; }
        public byte? C65 { get; set; }
        public byte? C66 { get; set; }
        public byte? C67 { get; set; }
        public byte? C68 { get; set; }
        public byte? C69 { get; set; }
        public byte? C70 { get; set; }
        public byte? C71 { get; set; }
        public byte? C72 { get; set; }
    }
}
