﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags6
    {
        public DateTime Utc { get; set; }
        public byte? FC121 { get; set; }
        public byte? FC122 { get; set; }
        public byte? FC123 { get; set; }
        public byte? FC124 { get; set; }
        public byte? FC125 { get; set; }
        public byte? FC126 { get; set; }
        public byte? FC127 { get; set; }
        public byte? FC128 { get; set; }
        public byte? FC129 { get; set; }
        public byte? FC130 { get; set; }
        public byte? FC131 { get; set; }
        public byte? FC132 { get; set; }
        public byte? FC133 { get; set; }
        public byte? FC134 { get; set; }
        public byte? FC135 { get; set; }
        public byte? FC136 { get; set; }
        public byte? FC137 { get; set; }
        public byte? FC138 { get; set; }
        public byte? FC139 { get; set; }
        public byte? FC140 { get; set; }
        public byte? FC141 { get; set; }
        public byte? FC142 { get; set; }
        public byte? FC143 { get; set; }
        public byte? FC144 { get; set; }
        public byte? GC121 { get; set; }
        public byte? GC122 { get; set; }
        public byte? GC123 { get; set; }
        public byte? GC124 { get; set; }
        public byte? GC125 { get; set; }
        public byte? GC126 { get; set; }
        public byte? GC127 { get; set; }
        public byte? GC128 { get; set; }
        public byte? GC129 { get; set; }
        public byte? GC130 { get; set; }
        public byte? GC131 { get; set; }
        public byte? GC132 { get; set; }
        public byte? GC133 { get; set; }
        public byte? GC134 { get; set; }
        public byte? GC135 { get; set; }
        public byte? GC136 { get; set; }
        public byte? GC137 { get; set; }
        public byte? GC138 { get; set; }
        public byte? GC139 { get; set; }
        public byte? GC140 { get; set; }
        public byte? GC141 { get; set; }
        public byte? GC142 { get; set; }
        public byte? GC143 { get; set; }
        public byte? GC144 { get; set; }
    }
}
