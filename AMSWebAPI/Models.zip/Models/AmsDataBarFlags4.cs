﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags4
    {
        public DateTime Utc { get; set; }
        public byte? FC73 { get; set; }
        public byte? FC74 { get; set; }
        public byte? FC75 { get; set; }
        public byte? FC76 { get; set; }
        public byte? FC77 { get; set; }
        public byte? FC78 { get; set; }
        public byte? FC79 { get; set; }
        public byte? FC80 { get; set; }
        public byte? FC81 { get; set; }
        public byte? FC82 { get; set; }
        public byte? FC83 { get; set; }
        public byte? FC84 { get; set; }
        public byte? FC85 { get; set; }
        public byte? FC86 { get; set; }
        public byte? FC87 { get; set; }
        public byte? FC88 { get; set; }
        public byte? FC89 { get; set; }
        public byte? FC90 { get; set; }
        public byte? FC91 { get; set; }
        public byte? FC92 { get; set; }
        public byte? FC93 { get; set; }
        public byte? FC94 { get; set; }
        public byte? FC95 { get; set; }
        public byte? FC96 { get; set; }
        public byte? GC73 { get; set; }
        public byte? GC74 { get; set; }
        public byte? GC75 { get; set; }
        public byte? GC76 { get; set; }
        public byte? GC77 { get; set; }
        public byte? GC78 { get; set; }
        public byte? GC79 { get; set; }
        public byte? GC80 { get; set; }
        public byte? GC81 { get; set; }
        public byte? GC82 { get; set; }
        public byte? GC83 { get; set; }
        public byte? GC84 { get; set; }
        public byte? GC85 { get; set; }
        public byte? GC86 { get; set; }
        public byte? GC87 { get; set; }
        public byte? GC88 { get; set; }
        public byte? GC89 { get; set; }
        public byte? GC90 { get; set; }
        public byte? GC91 { get; set; }
        public byte? GC92 { get; set; }
        public byte? GC93 { get; set; }
        public byte? GC94 { get; set; }
        public byte? GC95 { get; set; }
        public byte? GC96 { get; set; }
    }
}
