﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags2
    {
        public DateTime Utc { get; set; }
        public byte? FC25 { get; set; }
        public byte? FC26 { get; set; }
        public byte? FC27 { get; set; }
        public byte? FC28 { get; set; }
        public byte? FC29 { get; set; }
        public byte? FC30 { get; set; }
        public byte? FC31 { get; set; }
        public byte? FC32 { get; set; }
        public byte? FC33 { get; set; }
        public byte? FC34 { get; set; }
        public byte? FC35 { get; set; }
        public byte? FC36 { get; set; }
        public byte? FC37 { get; set; }
        public byte? FC38 { get; set; }
        public byte? FC39 { get; set; }
        public byte? FC40 { get; set; }
        public byte? FC41 { get; set; }
        public byte? FC42 { get; set; }
        public byte? FC43 { get; set; }
        public byte? FC44 { get; set; }
        public byte? FC45 { get; set; }
        public byte? FC46 { get; set; }
        public byte? FC47 { get; set; }
        public byte? FC48 { get; set; }
        public byte? GC25 { get; set; }
        public byte? GC26 { get; set; }
        public byte? GC27 { get; set; }
        public byte? GC28 { get; set; }
        public byte? GC29 { get; set; }
        public byte? GC30 { get; set; }
        public byte? GC31 { get; set; }
        public byte? GC32 { get; set; }
        public byte? GC33 { get; set; }
        public byte? GC34 { get; set; }
        public byte? GC35 { get; set; }
        public byte? GC36 { get; set; }
        public byte? GC37 { get; set; }
        public byte? GC38 { get; set; }
        public byte? GC39 { get; set; }
        public byte? GC40 { get; set; }
        public byte? GC41 { get; set; }
        public byte? GC42 { get; set; }
        public byte? GC43 { get; set; }
        public byte? GC44 { get; set; }
        public byte? GC45 { get; set; }
        public byte? GC46 { get; set; }
        public byte? GC47 { get; set; }
        public byte? GC48 { get; set; }
    }
}
