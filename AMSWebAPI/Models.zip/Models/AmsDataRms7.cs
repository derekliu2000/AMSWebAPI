﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms7
    {
        public DateTime Utc { get; set; }
        public short? C145 { get; set; }
        public short? C146 { get; set; }
        public short? C147 { get; set; }
        public short? C148 { get; set; }
        public short? C149 { get; set; }
        public short? C150 { get; set; }
        public short? C151 { get; set; }
        public short? C152 { get; set; }
        public short? C153 { get; set; }
        public short? C154 { get; set; }
        public short? C155 { get; set; }
        public short? C156 { get; set; }
        public short? C157 { get; set; }
        public short? C158 { get; set; }
        public short? C159 { get; set; }
        public short? C160 { get; set; }
        public short? C161 { get; set; }
        public short? C162 { get; set; }
        public short? C163 { get; set; }
        public short? C164 { get; set; }
        public short? C165 { get; set; }
        public short? C166 { get; set; }
        public short? C167 { get; set; }
        public short? C168 { get; set; }

        public virtual AmsDataRmsflags7 AmsDataRmsflags7 { get; set; }
    }
}
