﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags1
    {
        public DateTime Utc { get; set; }
        public byte? FC1 { get; set; }
        public byte? FC2 { get; set; }
        public byte? FC3 { get; set; }
        public byte? FC4 { get; set; }
        public byte? FC5 { get; set; }
        public byte? FC6 { get; set; }
        public byte? FC7 { get; set; }
        public byte? FC8 { get; set; }
        public byte? FC9 { get; set; }
        public byte? FC10 { get; set; }
        public byte? FC11 { get; set; }
        public byte? FC12 { get; set; }
        public byte? FC13 { get; set; }
        public byte? FC14 { get; set; }
        public byte? FC15 { get; set; }
        public byte? FC16 { get; set; }
        public byte? FC17 { get; set; }
        public byte? FC18 { get; set; }
        public byte? FC19 { get; set; }
        public byte? FC20 { get; set; }
        public byte? FC21 { get; set; }
        public byte? FC22 { get; set; }
        public byte? FC23 { get; set; }
        public byte? FC24 { get; set; }
        public byte? GC1 { get; set; }
        public byte? GC2 { get; set; }
        public byte? GC3 { get; set; }
        public byte? GC4 { get; set; }
        public byte? GC5 { get; set; }
        public byte? GC6 { get; set; }
        public byte? GC7 { get; set; }
        public byte? GC8 { get; set; }
        public byte? GC9 { get; set; }
        public byte? GC10 { get; set; }
        public byte? GC11 { get; set; }
        public byte? GC12 { get; set; }
        public byte? GC13 { get; set; }
        public byte? GC14 { get; set; }
        public byte? GC15 { get; set; }
        public byte? GC16 { get; set; }
        public byte? GC17 { get; set; }
        public byte? GC18 { get; set; }
        public byte? GC19 { get; set; }
        public byte? GC20 { get; set; }
        public byte? GC21 { get; set; }
        public byte? GC22 { get; set; }
        public byte? GC23 { get; set; }
        public byte? GC24 { get; set; }
    }
}
