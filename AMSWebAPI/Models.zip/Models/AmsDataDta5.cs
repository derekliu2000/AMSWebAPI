﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataDta5
    {
        public DateTime Utc { get; set; }
        public byte[] C97 { get; set; }
        public byte[] C98 { get; set; }
        public byte[] C99 { get; set; }
        public byte[] C100 { get; set; }
        public byte[] C101 { get; set; }
        public byte[] C102 { get; set; }
        public byte[] C103 { get; set; }
        public byte[] C104 { get; set; }
        public byte[] C105 { get; set; }
        public byte[] C106 { get; set; }
        public byte[] C107 { get; set; }
        public byte[] C108 { get; set; }
        public byte[] C109 { get; set; }
        public byte[] C110 { get; set; }
        public byte[] C111 { get; set; }
        public byte[] C112 { get; set; }
        public byte[] C113 { get; set; }
        public byte[] C114 { get; set; }
        public byte[] C115 { get; set; }
        public byte[] C116 { get; set; }
        public byte[] C117 { get; set; }
        public byte[] C118 { get; set; }
        public byte[] C119 { get; set; }
        public byte[] C120 { get; set; }
    }
}
