﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataDta6
    {
        public DateTime Utc { get; set; }
        public byte[] C121 { get; set; }
        public byte[] C122 { get; set; }
        public byte[] C123 { get; set; }
        public byte[] C124 { get; set; }
        public byte[] C125 { get; set; }
        public byte[] C126 { get; set; }
        public byte[] C127 { get; set; }
        public byte[] C128 { get; set; }
        public byte[] C129 { get; set; }
        public byte[] C130 { get; set; }
        public byte[] C131 { get; set; }
        public byte[] C132 { get; set; }
        public byte[] C133 { get; set; }
        public byte[] C134 { get; set; }
        public byte[] C135 { get; set; }
        public byte[] C136 { get; set; }
        public byte[] C137 { get; set; }
        public byte[] C138 { get; set; }
        public byte[] C139 { get; set; }
        public byte[] C140 { get; set; }
        public byte[] C141 { get; set; }
        public byte[] C142 { get; set; }
        public byte[] C143 { get; set; }
        public byte[] C144 { get; set; }
    }
}
