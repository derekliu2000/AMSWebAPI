﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms1
    {
        public DateTime Utc { get; set; }
        public short? C1 { get; set; }
        public short? C2 { get; set; }
        public short? C3 { get; set; }
        public short? C4 { get; set; }
        public short? C5 { get; set; }
        public short? C6 { get; set; }
        public short? C7 { get; set; }
        public short? C8 { get; set; }
        public short? C9 { get; set; }
        public short? C10 { get; set; }
        public short? C11 { get; set; }
        public short? C12 { get; set; }
        public short? C13 { get; set; }
        public short? C14 { get; set; }
        public short? C15 { get; set; }
        public short? C16 { get; set; }
        public short? C17 { get; set; }
        public short? C18 { get; set; }
        public short? C19 { get; set; }
        public short? C20 { get; set; }
        public short? C21 { get; set; }
        public short? C22 { get; set; }
        public short? C23 { get; set; }
        public short? C24 { get; set; }

        public virtual AmsDataRmsflags1 AmsDataRmsflags1 { get; set; }
    }
}
