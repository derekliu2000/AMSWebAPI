﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags7
    {
        public DateTime Utc { get; set; }
        public byte? FC145 { get; set; }
        public byte? FC146 { get; set; }
        public byte? FC147 { get; set; }
        public byte? FC148 { get; set; }
        public byte? FC149 { get; set; }
        public byte? FC150 { get; set; }
        public byte? FC151 { get; set; }
        public byte? FC152 { get; set; }
        public byte? FC153 { get; set; }
        public byte? FC154 { get; set; }
        public byte? FC155 { get; set; }
        public byte? FC156 { get; set; }
        public byte? FC157 { get; set; }
        public byte? FC158 { get; set; }
        public byte? FC159 { get; set; }
        public byte? FC160 { get; set; }
        public byte? FC161 { get; set; }
        public byte? FC162 { get; set; }
        public byte? FC163 { get; set; }
        public byte? FC164 { get; set; }
        public byte? FC165 { get; set; }
        public byte? FC166 { get; set; }
        public byte? FC167 { get; set; }
        public byte? FC168 { get; set; }
        public byte? GC145 { get; set; }
        public byte? GC146 { get; set; }
        public byte? GC147 { get; set; }
        public byte? GC148 { get; set; }
        public byte? GC149 { get; set; }
        public byte? GC150 { get; set; }
        public byte? GC151 { get; set; }
        public byte? GC152 { get; set; }
        public byte? GC153 { get; set; }
        public byte? GC154 { get; set; }
        public byte? GC155 { get; set; }
        public byte? GC156 { get; set; }
        public byte? GC157 { get; set; }
        public byte? GC158 { get; set; }
        public byte? GC159 { get; set; }
        public byte? GC160 { get; set; }
        public byte? GC161 { get; set; }
        public byte? GC162 { get; set; }
        public byte? GC163 { get; set; }
        public byte? GC164 { get; set; }
        public byte? GC165 { get; set; }
        public byte? GC166 { get; set; }
        public byte? GC167 { get; set; }
        public byte? GC168 { get; set; }
    }
}
