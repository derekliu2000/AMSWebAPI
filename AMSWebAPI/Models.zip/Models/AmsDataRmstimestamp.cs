﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRmstimestamp
    {
        public DateTime Utc { get; set; }
    }
}
