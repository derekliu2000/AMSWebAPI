﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms6
    {
        public DateTime Utc { get; set; }
        public short? C121 { get; set; }
        public short? C122 { get; set; }
        public short? C123 { get; set; }
        public short? C124 { get; set; }
        public short? C125 { get; set; }
        public short? C126 { get; set; }
        public short? C127 { get; set; }
        public short? C128 { get; set; }
        public short? C129 { get; set; }
        public short? C130 { get; set; }
        public short? C131 { get; set; }
        public short? C132 { get; set; }
        public short? C133 { get; set; }
        public short? C134 { get; set; }
        public short? C135 { get; set; }
        public short? C136 { get; set; }
        public short? C137 { get; set; }
        public short? C138 { get; set; }
        public short? C139 { get; set; }
        public short? C140 { get; set; }
        public short? C141 { get; set; }
        public short? C142 { get; set; }
        public short? C143 { get; set; }
        public short? C144 { get; set; }

        public virtual AmsDataRmsflags6 AmsDataRmsflags6 { get; set; }
    }
}
