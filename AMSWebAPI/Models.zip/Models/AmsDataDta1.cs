﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataDta1
    {
        public DateTime Utc { get; set; }
        public byte[] C1 { get; set; }
        public byte[] C2 { get; set; }
        public byte[] C3 { get; set; }
        public byte[] C4 { get; set; }
        public byte[] C5 { get; set; }
        public byte[] C6 { get; set; }
        public byte[] C7 { get; set; }
        public byte[] C8 { get; set; }
        public byte[] C9 { get; set; }
        public byte[] C10 { get; set; }
        public byte[] C11 { get; set; }
        public byte[] C12 { get; set; }
        public byte[] C13 { get; set; }
        public byte[] C14 { get; set; }
        public byte[] C15 { get; set; }
        public byte[] C16 { get; set; }
        public byte[] C17 { get; set; }
        public byte[] C18 { get; set; }
        public byte[] C19 { get; set; }
        public byte[] C20 { get; set; }
        public byte[] C21 { get; set; }
        public byte[] C22 { get; set; }
        public byte[] C23 { get; set; }
        public byte[] C24 { get; set; }
    }
}
