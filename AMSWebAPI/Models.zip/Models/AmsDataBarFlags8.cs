﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags8
    {
        public DateTime Utc { get; set; }
        public byte? FC169 { get; set; }
        public byte? FC170 { get; set; }
        public byte? FC171 { get; set; }
        public byte? FC172 { get; set; }
        public byte? FC173 { get; set; }
        public byte? FC174 { get; set; }
        public byte? FC175 { get; set; }
        public byte? FC176 { get; set; }
        public byte? FC177 { get; set; }
        public byte? FC178 { get; set; }
        public byte? FC179 { get; set; }
        public byte? FC180 { get; set; }
        public byte? FC181 { get; set; }
        public byte? FC182 { get; set; }
        public byte? FC183 { get; set; }
        public byte? FC184 { get; set; }
        public byte? FC185 { get; set; }
        public byte? FC186 { get; set; }
        public byte? FC187 { get; set; }
        public byte? FC188 { get; set; }
        public byte? FC189 { get; set; }
        public byte? FC190 { get; set; }
        public byte? FC191 { get; set; }
        public byte? FC192 { get; set; }
        public byte? GC169 { get; set; }
        public byte? GC170 { get; set; }
        public byte? GC171 { get; set; }
        public byte? GC172 { get; set; }
        public byte? GC173 { get; set; }
        public byte? GC174 { get; set; }
        public byte? GC175 { get; set; }
        public byte? GC176 { get; set; }
        public byte? GC177 { get; set; }
        public byte? GC178 { get; set; }
        public byte? GC179 { get; set; }
        public byte? GC180 { get; set; }
        public byte? GC181 { get; set; }
        public byte? GC182 { get; set; }
        public byte? GC183 { get; set; }
        public byte? GC184 { get; set; }
        public byte? GC185 { get; set; }
        public byte? GC186 { get; set; }
        public byte? GC187 { get; set; }
        public byte? GC188 { get; set; }
        public byte? GC189 { get; set; }
        public byte? GC190 { get; set; }
        public byte? GC191 { get; set; }
        public byte? GC192 { get; set; }
    }
}
