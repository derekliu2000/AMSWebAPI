﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataDta4
    {
        public DateTime Utc { get; set; }
        public byte[] C73 { get; set; }
        public byte[] C74 { get; set; }
        public byte[] C75 { get; set; }
        public byte[] C76 { get; set; }
        public byte[] C77 { get; set; }
        public byte[] C78 { get; set; }
        public byte[] C79 { get; set; }
        public byte[] C80 { get; set; }
        public byte[] C81 { get; set; }
        public byte[] C82 { get; set; }
        public byte[] C83 { get; set; }
        public byte[] C84 { get; set; }
        public byte[] C85 { get; set; }
        public byte[] C86 { get; set; }
        public byte[] C87 { get; set; }
        public byte[] C88 { get; set; }
        public byte[] C89 { get; set; }
        public byte[] C90 { get; set; }
        public byte[] C91 { get; set; }
        public byte[] C92 { get; set; }
        public byte[] C93 { get; set; }
        public byte[] C94 { get; set; }
        public byte[] C95 { get; set; }
        public byte[] C96 { get; set; }
    }
}
