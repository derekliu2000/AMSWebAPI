﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms8
    {
        public DateTime Utc { get; set; }
        public short? C169 { get; set; }
        public short? C170 { get; set; }
        public short? C171 { get; set; }
        public short? C172 { get; set; }
        public short? C173 { get; set; }
        public short? C174 { get; set; }
        public short? C175 { get; set; }
        public short? C176 { get; set; }
        public short? C177 { get; set; }
        public short? C178 { get; set; }
        public short? C179 { get; set; }
        public short? C180 { get; set; }
        public short? C181 { get; set; }
        public short? C182 { get; set; }
        public short? C183 { get; set; }
        public short? C184 { get; set; }
        public short? C185 { get; set; }
        public short? C186 { get; set; }
        public short? C187 { get; set; }
        public short? C188 { get; set; }
        public short? C189 { get; set; }
        public short? C190 { get; set; }
        public short? C191 { get; set; }
        public short? C192 { get; set; }

        public virtual AmsDataRmsflags8 AmsDataRmsflags8 { get; set; }
    }
}
