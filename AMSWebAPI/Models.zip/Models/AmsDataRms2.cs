﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms2
    {
        public DateTime Utc { get; set; }
        public short? C25 { get; set; }
        public short? C26 { get; set; }
        public short? C27 { get; set; }
        public short? C28 { get; set; }
        public short? C29 { get; set; }
        public short? C30 { get; set; }
        public short? C31 { get; set; }
        public short? C32 { get; set; }
        public short? C33 { get; set; }
        public short? C34 { get; set; }
        public short? C35 { get; set; }
        public short? C36 { get; set; }
        public short? C37 { get; set; }
        public short? C38 { get; set; }
        public short? C39 { get; set; }
        public short? C40 { get; set; }
        public short? C41 { get; set; }
        public short? C42 { get; set; }
        public short? C43 { get; set; }
        public short? C44 { get; set; }
        public short? C45 { get; set; }
        public short? C46 { get; set; }
        public short? C47 { get; set; }
        public short? C48 { get; set; }

        public virtual AmsDataRmsflags2 AmsDataRmsflags2 { get; set; }
    }
}
