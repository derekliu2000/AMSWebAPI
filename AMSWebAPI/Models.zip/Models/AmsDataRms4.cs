﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms4
    {
        public DateTime Utc { get; set; }
        public short? C73 { get; set; }
        public short? C74 { get; set; }
        public short? C75 { get; set; }
        public short? C76 { get; set; }
        public short? C77 { get; set; }
        public short? C78 { get; set; }
        public short? C79 { get; set; }
        public short? C80 { get; set; }
        public short? C81 { get; set; }
        public short? C82 { get; set; }
        public short? C83 { get; set; }
        public short? C84 { get; set; }
        public short? C85 { get; set; }
        public short? C86 { get; set; }
        public short? C87 { get; set; }
        public short? C88 { get; set; }
        public short? C89 { get; set; }
        public short? C90 { get; set; }
        public short? C91 { get; set; }
        public short? C92 { get; set; }
        public short? C93 { get; set; }
        public short? C94 { get; set; }
        public short? C95 { get; set; }
        public short? C96 { get; set; }

        public virtual AmsDataRmsflags4 AmsDataRmsflags4 { get; set; }
    }
}
