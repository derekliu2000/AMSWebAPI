﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataBarFlags3
    {
        public DateTime Utc { get; set; }
        public byte? FC49 { get; set; }
        public byte? FC50 { get; set; }
        public byte? FC51 { get; set; }
        public byte? FC52 { get; set; }
        public byte? FC53 { get; set; }
        public byte? FC54 { get; set; }
        public byte? FC55 { get; set; }
        public byte? FC56 { get; set; }
        public byte? FC57 { get; set; }
        public byte? FC58 { get; set; }
        public byte? FC59 { get; set; }
        public byte? FC60 { get; set; }
        public byte? FC61 { get; set; }
        public byte? FC62 { get; set; }
        public byte? FC63 { get; set; }
        public byte? FC64 { get; set; }
        public byte? FC65 { get; set; }
        public byte? FC66 { get; set; }
        public byte? FC67 { get; set; }
        public byte? FC68 { get; set; }
        public byte? FC69 { get; set; }
        public byte? FC70 { get; set; }
        public byte? FC71 { get; set; }
        public byte? FC72 { get; set; }
        public byte? GC49 { get; set; }
        public byte? GC50 { get; set; }
        public byte? GC51 { get; set; }
        public byte? GC52 { get; set; }
        public byte? GC53 { get; set; }
        public byte? GC54 { get; set; }
        public byte? GC55 { get; set; }
        public byte? GC56 { get; set; }
        public byte? GC57 { get; set; }
        public byte? GC58 { get; set; }
        public byte? GC59 { get; set; }
        public byte? GC60 { get; set; }
        public byte? GC61 { get; set; }
        public byte? GC62 { get; set; }
        public byte? GC63 { get; set; }
        public byte? GC64 { get; set; }
        public byte? GC65 { get; set; }
        public byte? GC66 { get; set; }
        public byte? GC67 { get; set; }
        public byte? GC68 { get; set; }
        public byte? GC69 { get; set; }
        public byte? GC70 { get; set; }
        public byte? GC71 { get; set; }
        public byte? GC72 { get; set; }
    }
}
