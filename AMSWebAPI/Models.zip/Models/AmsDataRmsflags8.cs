﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRmsflags8
    {
        public DateTime Utc { get; set; }
        public byte? C169 { get; set; }
        public byte? C170 { get; set; }
        public byte? C171 { get; set; }
        public byte? C172 { get; set; }
        public byte? C173 { get; set; }
        public byte? C174 { get; set; }
        public byte? C175 { get; set; }
        public byte? C176 { get; set; }
        public byte? C177 { get; set; }
        public byte? C178 { get; set; }
        public byte? C179 { get; set; }
        public byte? C180 { get; set; }
        public byte? C181 { get; set; }
        public byte? C182 { get; set; }
        public byte? C183 { get; set; }
        public byte? C184 { get; set; }
        public byte? C185 { get; set; }
        public byte? C186 { get; set; }
        public byte? C187 { get; set; }
        public byte? C188 { get; set; }
        public byte? C189 { get; set; }
        public byte? C190 { get; set; }
        public byte? C191 { get; set; }
        public byte? C192 { get; set; }

        public virtual AmsDataRms8 UtcNavigation { get; set; }
    }
}
