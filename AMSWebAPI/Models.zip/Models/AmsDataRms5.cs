﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsDataRms5
    {
        public DateTime Utc { get; set; }
        public short? C97 { get; set; }
        public short? C98 { get; set; }
        public short? C99 { get; set; }
        public short? C100 { get; set; }
        public short? C101 { get; set; }
        public short? C102 { get; set; }
        public short? C103 { get; set; }
        public short? C104 { get; set; }
        public short? C105 { get; set; }
        public short? C106 { get; set; }
        public short? C107 { get; set; }
        public short? C108 { get; set; }
        public short? C109 { get; set; }
        public short? C110 { get; set; }
        public short? C111 { get; set; }
        public short? C112 { get; set; }
        public short? C113 { get; set; }
        public short? C114 { get; set; }
        public short? C115 { get; set; }
        public short? C116 { get; set; }
        public short? C117 { get; set; }
        public short? C118 { get; set; }
        public short? C119 { get; set; }
        public short? C120 { get; set; }

        public virtual AmsDataRmsflags5 AmsDataRmsflags5 { get; set; }
    }
}
