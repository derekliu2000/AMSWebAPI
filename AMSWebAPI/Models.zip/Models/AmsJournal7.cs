﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMSWebAPI.Models
{
    public partial class AmsJournal7
    {
        public DateTime Utc { get; set; }
        public byte? C145 { get; set; }
        public byte? C146 { get; set; }
        public byte? C147 { get; set; }
        public byte? C148 { get; set; }
        public byte? C149 { get; set; }
        public byte? C150 { get; set; }
        public byte? C151 { get; set; }
        public byte? C152 { get; set; }
        public byte? C153 { get; set; }
        public byte? C154 { get; set; }
        public byte? C155 { get; set; }
        public byte? C156 { get; set; }
        public byte? C157 { get; set; }
        public byte? C158 { get; set; }
        public byte? C159 { get; set; }
        public byte? C160 { get; set; }
        public byte? C161 { get; set; }
        public byte? C162 { get; set; }
        public byte? C163 { get; set; }
        public byte? C164 { get; set; }
        public byte? C165 { get; set; }
        public byte? C166 { get; set; }
        public byte? C167 { get; set; }
        public byte? C168 { get; set; }
    }
}
