﻿using AMSWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmsDataAuxesController : ControllerBase
    {
        private readonly AMS_SiteContext _context;

        public AmsDataAuxesController(AMS_SiteContext context)
        {            
            _context = context;
        }

        // GET: api/AmsDataAuxes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AmsDataAux>>> GetAmsDataAuxes(string DBName)
        {
            // Method 1: create new context
            //var contextOptions = new DbContextOptionsBuilder<AMS_SiteContext>()
            //    .UseSqlServer("Server=10.32.66.230\\sqlexpress2019;Database=AMS_Site;UID=ams;Password=Mistras1;MultipleActiveResultSets=true")
            //    .Options;

            //using (var context = new AMS_SiteContext(contextOptions))
            //{
            //    return await context.AmsDataAuxes.ToListAsync();
            //}

            // Method 2: create new context
            //using (AMS_SiteContext dbContext = new AMS_SiteContext("Server=10.32.66.230\\sqlexpress2019;Database=AMS_Site;UID=ams;Password=Mistras1;MultipleActiveResultSets=true"))
            //{
            //    return await dbContext.AmsDataAuxes.ToListAsync();
            //}

            // Method 3: change connection string of existing context
            _context.SetDatabase("AMS_Site");
            return await _context.AmsDataAuxes.ToListAsync();
        }

        // GET: api/AmsDataAuxes/5
        [HttpGet("{UTC}")]
        public async Task<ActionResult<AmsDataAux>> GetAmsDataAux(string DBName, DateTime UTC)
        {
            _context.SetDatabase(DBName);
            var amsDataAux = await _context.AmsDataAuxes.FindAsync(UTC);

            if (amsDataAux == null)
            {
                return NotFound();
            }

            return amsDataAux;
        }

        [HttpGet("maxUTC")]
        public async Task<ActionResult<DateTime>> MaxUTC(string DBName)
        {
            _context.SetDatabase(DBName);
            return await _context.AmsDataAuxes.MaxAsync(x => x.Utc);
        }

        // PUT: api/AmsDataAuxes/5
        // Modify existing record
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{UTC}")]
        public async Task<IActionResult> PutAmsDataAux(string DBName, DateTime UTC, AmsDataAux amsDataAux)
        {
            _context.SetDatabase(DBName);

            if (UTC != amsDataAux.Utc)
            {
                return BadRequest();
            }

            _context.Entry(amsDataAux).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AmsDataAuxExists(UTC))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AmsDataAuxes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AmsDataAux>> PostAmsDataAux(AmsDataAux amsDataAux)
        {
            //_context.SetDatabase("");

            _context.AmsDataAuxes.Add(amsDataAux);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AmsDataAuxExists(amsDataAux.Utc))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAmsDataAux", new { id = amsDataAux.Utc }, amsDataAux);
        }

        // DELETE: api/AmsDataAuxes/5
        [HttpDelete("{UTC}")]
        public async Task<IActionResult> DeleteAmsDataAux(string DBName, DateTime UTC)
        {
            _context.SetDatabase(DBName);

            var amsDataAux = await _context.AmsDataAuxes.FindAsync(UTC);
            if (amsDataAux == null)
            {
                return NotFound();
            }

            _context.AmsDataAuxes.Remove(amsDataAux);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AmsDataAuxExists(DateTime UTC)
        {
            return _context.AmsDataAuxes.Any(e => e.Utc == UTC);
        }
    }
}
