﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AMSWebAPI.Models;

namespace AMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmsJournal1Controller : ControllerBase
    {
        private readonly AMS_SiteContext _context;

        public AmsJournal1Controller(AMS_SiteContext context)
        {
            _context = context;
        }

        // GET: api/AmsJournal1
        // https://localhost:44368/api/AmsJournal1
        // curl -X GET "https://localhost:44368/api/AmsJournal1" -H  "accept: text/plain"
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AmsJournal1>>> GetAmsJournal1s()
        {
            _context.SetDatabase(Request);
            return await _context.AmsJournal1s.ToListAsync();
        }

        // GET: api/AmsJournal1/5
        [HttpGet("{UTC}")]
        public async Task<ActionResult<AmsJournal1>> GetAmsJournal1(DateTime UTC)
        {
            _context.SetDatabase(Request);
            var amsJournal1 = await _context.AmsJournal1s.FindAsync(UTC);

            if (amsJournal1 == null)
            {
                return NotFound();
            }

            return amsJournal1;
        }

        // PUT: api/AmsJournal1/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{UTC}")]
        public async Task<IActionResult> PutAmsJournal1(DateTime UTC, AmsJournal1 amsJournal1)
        {
            _context.SetDatabase(Request);
            if (UTC != amsJournal1.Utc)
            {
                return BadRequest();
            }

            _context.Entry(amsJournal1).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AmsJournal1Exists(UTC))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AmsJournal1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AmsJournal1>> PostAmsJournal1(AmsJournal1 amsJournal1)
        {
            _context.SetDatabase(Request);
            _context.AmsJournal1s.Add(amsJournal1);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AmsJournal1Exists(amsJournal1.Utc))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAmsJournal1", new { UTC = amsJournal1.Utc }, amsJournal1);
        }

        private bool AmsJournal1Exists(DateTime UTC)
        {
            return _context.AmsJournal1s.Any(e => e.Utc == UTC);
        }
    }
}
