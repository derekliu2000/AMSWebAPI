﻿using AMSWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmsDataBarsController : ControllerBase
    {
        private readonly AMS_SiteContext _context;
        
        public AmsDataBarsController(AMS_SiteContext context)
        {
            _context = context;            
        }

        // GET: api/AmsDataBars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AmsDataBar>>> GetAmsDataBars()
        {
            _context.Database.GetDbConnection().ConnectionString = "Server=10.32.66.230\\sqlexpress2019;Database=AMS_Site;UID=sa;Password=Mistras1;MultipleActiveResultSets=true";
            return await _context.AmsDataBars.ToListAsync();
        }

        // GET: api/AmsDataBars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AmsDataBar>> GetAmsDataBar(int id)
        {
            var amsDataBar = await _context.AmsDataBars.FindAsync(id);

            if (amsDataBar == null)
            {
                return NotFound();
            }

            return amsDataBar;
        }

        // PUT: api/AmsDataBars/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAmsDataBar(int id, AmsDataBar amsDataBar)
        {
            if (id != amsDataBar.Id)
            {
                return BadRequest();
            }

            _context.Entry(amsDataBar).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AmsDataBarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AmsDataBars
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AmsDataBar>> PostAmsDataBar(AmsDataBar amsDataBar)
        {
            _context.AmsDataBars.Add(amsDataBar);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAmsDataBar", new { id = amsDataBar.Id }, amsDataBar);
        }

        // DELETE: api/AmsDataBars/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAmsDataBar(int id)
        {
            var amsDataBar = await _context.AmsDataBars.FindAsync(id);
            if (amsDataBar == null)
            {
                return NotFound();
            }

            _context.AmsDataBars.Remove(amsDataBar);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AmsDataBarExists(int id)
        {
            return _context.AmsDataBars.Any(e => e.Id == id);
        }
    }
}
