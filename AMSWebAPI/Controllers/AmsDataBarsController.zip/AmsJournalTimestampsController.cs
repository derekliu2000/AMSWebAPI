﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AMSWebAPI.Models;

namespace AMSWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmsJournalTimestampsController : ControllerBase
    {
        private readonly AMS_SiteContext _context;

        public AmsJournalTimestampsController(AMS_SiteContext context)
        {
            _context = context;
        }

        // GET: api/AmsJournalTimestamps
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AmsJournalTimestamp>>> GetAmsJournalTimestamps()
        {
            return await _context.AmsJournalTimestamps.ToListAsync();
        }

        // GET: api/AmsJournalTimestamps/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AmsJournalTimestamp>> GetAmsJournalTimestamp(DateTime id)
        {
            var amsJournalTimestamp = await _context.AmsJournalTimestamps.FindAsync(id);

            if (amsJournalTimestamp == null)
            {
                return NotFound();
            }

            return amsJournalTimestamp;
        }

        // PUT: api/AmsJournalTimestamps/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAmsJournalTimestamp(DateTime id, AmsJournalTimestamp amsJournalTimestamp)
        {
            if (id != amsJournalTimestamp.Utc)
            {
                return BadRequest();
            }

            _context.Entry(amsJournalTimestamp).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AmsJournalTimestampExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AmsJournalTimestamps
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AmsJournalTimestamp>> PostAmsJournalTimestamp(AmsJournalTimestamp amsJournalTimestamp)
        {
            _context.AmsJournalTimestamps.Add(amsJournalTimestamp);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AmsJournalTimestampExists(amsJournalTimestamp.Utc))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAmsJournalTimestamp", new { id = amsJournalTimestamp.Utc }, amsJournalTimestamp);
        }

        // DELETE: api/AmsJournalTimestamps/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAmsJournalTimestamp(DateTime id)
        {
            var amsJournalTimestamp = await _context.AmsJournalTimestamps.FindAsync(id);
            if (amsJournalTimestamp == null)
            {
                return NotFound();
            }

            _context.AmsJournalTimestamps.Remove(amsJournalTimestamp);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AmsJournalTimestampExists(DateTime id)
        {
            return _context.AmsJournalTimestamps.Any(e => e.Utc == id);
        }
    }
}
